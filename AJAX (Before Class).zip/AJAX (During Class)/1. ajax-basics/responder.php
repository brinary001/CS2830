<?php
// Created by Professor Wergeles for CS2830 at the University of Missouri


    // We did this to simulate the server taking extra time to process a request
   	//sleep(3);
    
    print "Hello AJAX!";
?>